# CS 6456 Grad Project
GestureLock: A Gesture-Based Authentication System
- All required libraries and packages located in requirements.txt
