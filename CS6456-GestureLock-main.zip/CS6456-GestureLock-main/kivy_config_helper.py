#!/usr/bin/env python
""" Helper routine for loading/creating a config file for kivy apps and optionally simulate different output devices.

Call config_kivy() to load/create a config file, optionally setting/overriding the window dimensions. The window
dimensions are returned, which is useful if you need to pass those dims to your layout code. Also, there is an optional
feature that allows simulation of other devices display capabilities when running windowed Kivy apps (discussed below).

A successful call to config_kivy() will result in an existing config file being loaded if it already exists, or
a new config file being created, if not. If a new file is created, it will be populated with Kivy's default settings. If
window_width and/or window_height are provided, those values will replace the config settings under [graphics] width
and height. The config file is expected to be the same base file name as the calling Python file, but with ".config"
as the extension. The parent path is the same as the calling Python file. If the file doesn't exist, it gets created.

NOTE: config_kivy() should _usually_ be called from the top of your main Kivy app file. The first lines of executable
code should appear similar to the following:

    from kivy_config_helper import config_kivy
    config_kivy(....)

There may occasionally be exceptions. The main thing is that the import statement and call to config_kivy() should
happen before other Kivy modules are imported. If you don't Kivy may initialize before the adjustments get applied.

This requirement is due to the use of OS environment variables that configure kivy when loading the library, and
bootstrapping of the config file.

Function Description

    def config_kivy(
                    window_width=None, # width of app window. will be the value set in config file (perhaps overriding
                                        existing file, if already present).
                    window_height=None, # height of app window. will be the value set in config file (perhaps overriding
                                        existing file, if already present).
                    simulate_device=False, # set to True if you wish to simulate another device
                    curr_device_density=None, # (float) Set if you wish to simulate another device
                    simulate_dpi=None, # (int) Set if you wish to simulate another device
                    simulate_density=None # (float) Set if you wish to simulate another device
                    ):

Returns a tuple of (width, height) of the window. This is either the window_width and window_height you passed, or it
is the [graphics] width and height from the existing config file.

Example calls

    # Create/Load config and use 800x600 resolution.
    config_kivy(window_width=800, window_height=600)

    # Create/Load config and use whatever resolution is present in config (possibly Kivy default). Also, use
    # returned app window resolution
    app_window_width, app_window_height = config_kivy()

Simulation

The simulation feature allows you to simulate another device with different display characteristics. This is helpful
to ensure that your Kivy layout is device independent. Note that this only works for windowed mode apps. This code
would need to be modified slightly for full screen apps, and your GUI layout would need to be flexible to handle
different aspect ratios.

The simulation feature creates/revises an additional config file in the same parent path as the normal config file.
However, the file name is the base file name of the calling Python code with extension ".sim.config". This config
is populated with exactly the same config as the normal config, but possibly with changes to the [graphics] width
and height. This config file is used during the simulation.

To simulate another device, set simulate_device=True and also provide curr_device_density (float), simulate_dpi (int),
and simulate_density (float). All four parameters must be set. See below for details.

If you want to simulate another device, you need to first determine what the density is of your display on the
machine you wish to simulate on.

Determine your display by running the following in build() of your app:

    dpi = kivy.metrics.Metrics.dpi
    dens = kivy.metrics.Metrics.density
    dp2pixel = kivy.metrics.dp(1)
    print(f'dpi: {dpi}, dens: {dens}, dp(1): {dp2pixel}')

Next, decide what the characteristics are of the device you wish to simulate. Here are some examples:

    # Generic
    # kivy_simulate_dpi = 100
    # kivy_simulate_density = 1.0

    # Macbook Pro 2023 14"
    # kivy_simulate_dpi = 192
    # kivy_simulate_density = 2.0

    # Fancy Device
    # kivy_simulate_dpi = 250
    # kivy_simulate_density = 2.5

    # Not Fancy Device
    # kivy_simulate_dpi = 50
    # kivy_simulate_density = 0.5

Example call:

    # If you have a Mac Retina Display, and want to simulate a basic display, your command might look like this
    # The window will look smaller than normal, but ideally your GUI layout should maintain proportions.

    config_kivy(simulate_device=True, curr_device_density=2.0, simulate_dpi=100, simulate_density=1.0)


"""

__author__ = "Jeff Wilson, PhD"
__contact__ = "jeff@ipat.gatech.edu"
__copyright__ = "Copyright 2013, Georgia Institute of Technology"
__date__ = "2013/08/17"
__deprecated__ = False
__email__ = "jeff@ipat.gatech.edu"
__status__ = "Production"
__version__ = "0.0.1"

import os
import shutil
from pathlib import Path
import inspect
from kivy.config import Config


def config_kivy(window_width=None, window_height=None,
                simulate_device=False,
                curr_device_density=None,
                simulate_dpi=None, simulate_density=None):

    # find the name of calling python file
    # will make (or use existing) a config file with same basename and store in same dir
    frame = inspect.stack()[1]
    module = inspect.getmodule(frame[0])
    callerfname = module.__file__
    po = Path(callerfname)
    callerbasefname = po.stem
    callerbasepath = po.parent
    configfname = callerbasefname + ".config"
    configpath = str(Path(callerbasepath).joinpath(configfname))


    if not os.path.isfile(configpath):
        with open(configpath, "w+") as f:
            pass
    Config.read(configpath)

    if window_width is None:
        internal_window_width = int(Config.get('graphics', 'width'))
    else:
        internal_window_width = window_width
        Config.set('graphics', 'width', str(int(internal_window_width)))
        Config.write()

    if window_height is None:
        internal_window_height = int(Config.get('graphics', 'height'))
    else:
        internal_window_height = window_height
        Config.set('graphics', 'height', str(int(internal_window_height)))
        Config.write()

    if not simulate_device:
        # if these are set externally, we'll ignore and use default dpi and density of device
        os.environ.pop('KIVY_DPI', None)
        os.environ.pop('KIVY_METRICS_DENSITY', None)
    else:
        if not curr_device_density or not simulate_dpi or not simulate_density:
            simulate_device = False
            raise ValueError("if simulate_device is set to True, then "
                             "curr_device_density, simulate_dpi, and simulate_density must all be set!")

        simconfigfname = callerbasefname + ".sim.config"
        simconfigpath = str(Path(callerbasepath).joinpath(simconfigfname))
        shutil.copy2(configpath, simconfigpath)
        Config.read(simconfigpath)

        # Note the following simulation strategy assumes you want to simulate the same resolution
        # window (e.g. Kivy app in windowed mode) on various devices. If you want to simulate different
        # full screen apps, then some changes are necessary.

        # For some reason, you can only override Kivy's initial DPI and Density
        # via environment variables.

        os.environ['KIVY_DPI'] = str(simulate_dpi)
        os.environ['KIVY_METRICS_DENSITY'] = str(simulate_density)

        # This scales window size appropriately
        sim_window_width = int(internal_window_width / curr_device_density * simulate_density)
        sim_window_height = int(internal_window_height / curr_device_density * simulate_density)

        # Make resolution adjustments. The end result is you should see your app the same in any
        # simulation config, just bigger or smaller. For instance, if you have a Retina Macbook, then
        # you'll see a generic sim as a smaller window and your widgets and layout all proportionally adjusted.
        # If not, then you forgot to use relative layout and/or didn't use density independent pixel calculations.

        Config.set('graphics', 'width', str(sim_window_width))
        Config.set('graphics', 'height', str(sim_window_height))

        Config.write()

    return internal_window_width, internal_window_height