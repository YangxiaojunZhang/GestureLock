from kivy_config_helper import config_kivy
scr_w, scr_h = config_kivy(window_width=600, window_height=800, simulate_device=False, curr_device_density=2.0, simulate_dpi=100, simulate_density=1.0)

import math
import numpy as np
import time
import json
from random import random
from pymongo import MongoClient
from kivy.app import App
from kivy.config import Config
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.properties import ObjectProperty, BooleanProperty, NumericProperty, ListProperty
from kivy.uix.popup import Popup
from kivy.uix.widget import Widget
from kivy.graphics import Line, Color
from kivy.vector import Vector
from kivy.clock import Clock
from kivy.multistroke import Recognizer

Config.set('graphics', 'resizable', '0')

Builder.load_file('LoginScreen.kv')
Builder.load_file('CreateAccountScreen.kv')
Builder.load_file('LoginSuccessfulScreen.kv')
Builder.load_file('ChangePasswordScreen.kv')

screen_manager = ScreenManager()
recognizer = Recognizer()

SIMILARITY_THRESHOLD = 0.75
MINIMUM_GESTURES = 3
MINIMUM_DIVERSITY = 0.3
MINIMUM_LENGTH = 2500
RATE_LIMIT_WINDOW = 300
MAX_LOGIN_ATTEMPTS = 5

####################################################################################
# Helper Functions #
####################################################################################
def get_points(strokes):
    points = []
    for line in strokes:
        line_points = [(x, y) for x, y in zip(line.points[::2], line.points[1::2])]
        points.append(line_points)
    return points

def get_vectors(strokes):
    vectors = []
    for line in strokes:
        lpts = line.points
        vectors.append([Vector(*pts) for pts in zip(lpts[::2], lpts[1::2])])
    return vectors

def draw_checkmark(gesture_surface):
    with gesture_surface.canvas:
                Color(0, 1, 0)
                x = gesture_surface.width * 0.5
                y = gesture_surface.height * 0.9
                w = gesture_surface.width * 0.6
                h = gesture_surface.height * 0.4
                Line(points=[x - w * 0.2, y - h * 0.1,
                             x - w * 0.05, y - h * 0.25,
                             x + w * 0.35, y + h * 0.2], width=20)

def draw_x(gesture_surface):
        with gesture_surface.canvas:
            Color(1, 0, 0)
            x = gesture_surface.width * 0.5
            y = gesture_surface.height * 0.9
            size = min(gesture_surface.width, gesture_surface.height) * 0.3

            Line(points=[x - size * 0.5, y - size * 0.5,
                         x + size * 0.5, y + size * 0.5], width=20)

            Line(points=[x - size * 0.5, y + size * 0.5,
                         x + size * 0.5, y - size * 0.5], width=20)
            
####################################################################################
# Password Validity Functions #
####################################################################################
def check_complexity(password):
    if len(password) < MINIMUM_GESTURES:
        return False
    
    all_angles = []
    total_length = 0

    for stroke in password:
        angles = []
        for i in range(1, len(stroke)):
            dx = stroke[i][0] - stroke[i - 1][0]
            dy = stroke[i][1] - stroke[i - 1][1]

            angle = math.atan2(dy, dx)
            angles.append(angle)

            length = math.hypot(dx, dy)
            total_length += length

        all_angles.extend(angles)

    variance = np.var(all_angles)
    diversity = (variance / (2 * np.pi))

    if diversity < MINIMUM_DIVERSITY or total_length < MINIMUM_LENGTH:
        return False
    return True

def compare_gesture_timing(original, entered):
    if len(original) != len(entered):
        return False
    
    times_distance = np.linalg.norm(np.array(original) - np.array(entered))

    TIMING_THRESHOLD = 0.1 * len(original)
    if times_distance < TIMING_THRESHOLD:
        return True
    else:
        return False

####################################################################################
# Popup Functions #
####################################################################################
class AccountCreationPopup(Popup):
    def go_to_login_screen(self):
        self.dismiss()
        screen_manager.transition = SlideTransition(direction='right')
        screen_manager.current = "Login" 

class InvalidRepetitionPopup(Popup):
    def __init__(self, **kwargs):
        super(InvalidRepetitionPopup, self).__init__(**kwargs)
        Clock.schedule_once(self.dismiss_popup, 3)

    def dismiss_popup(self, dt):
        self.dismiss()

class SimplePasswordPopup(Popup):
    pass

class PasswordInstructionPopup(Popup):
    pass

class PasswordInfoPopup(Popup):
    pass

class UserDoesNotExistPopup(Popup):
    pass

class PasswordWrongPopup(Popup):
    pass

class RateLimitPopup(Popup):
    def update_text(self, remaining_time):
        self.ids.remaining_time_label.text = f"Rate Limit Exceeded. Please wait for {remaining_time} minute(s) before trying again."

class PasswordUpdatedPopup(Popup):
    def go_to_login_screen(self):
        self.dismiss()
        screen_manager.transition = SlideTransition(direction='right')
        screen_manager.current = "Login" 

####################################################################################
# Gesture Surface #
####################################################################################
class MyGestureSurface(Widget):
    strokes = ListProperty([])
    stroke_times = ListProperty([])
    time_between_strokes = ListProperty([])
    use_random_color = BooleanProperty(False)
    draw_timeout = NumericProperty(2)
    max_strokes = NumericProperty(20)
    gesture_completed = BooleanProperty(False)
    current_screen = ObjectProperty()

    def __init__(self, **kwargs):
        super(MyGestureSurface, self).__init__(**kwargs)
        self.draw_timeout_clock = None
        self.inactivity_timeout = 2
        self.last_action = None
        self.start_time = None
        self.bind(gesture_completed=self.on_gesture_completed)

        Clock.schedule_interval(self.check_for_inactivity, 1.0 / 60.0)

    def check_for_inactivity(self, dt):
        if self.last_action is None or self.draw_timeout_clock is not None:
            return

        if time.time() - self.last_action > self.inactivity_timeout:
            self.on_inactivity_timeout()

    def on_gesture_completed(self, instance, value):
        if value:
            self.current_screen.gesture_completed()          

    def on_touch_down(self, touch):
        if self.draw_timeout_clock is not None or self.gesture_completed or not self.collide_point(*touch.pos):
            return
        
        self.last_action = time.time()
        
        if self.start_time:
            self.time_between_strokes.append(time.time() - self.start_time)
        self.start_time = time.time()
              
        with self.canvas:
            if self.use_random_color:
                Color(random(), random(), random())
            else:
                Color(0, 0, 0)
            touch.ud['gesture'] = Line(points=(touch.x, touch.y), width=2)

    def on_touch_move(self, touch):
        if 'gesture' in touch.ud and self.collide_point(*touch.pos):
            touch.ud['gesture'].points += [touch.x, touch.y]
            self.last_action = time.time()

    def on_touch_up(self, touch):
        if 'gesture' in touch.ud:
            self.strokes.append(touch.ud['gesture'])
            touch.ungrab(self)

            self.stroke_times.append(time.time() - self.start_time)
            self.start_time = time.time()

            if len(self.strokes) >= self.max_strokes:
                self.draw_timeout_clock = Clock.schedule_once(self.on_draw_timeout, self.draw_timeout)

    def on_inactivity_timeout(self):
        if self.draw_timeout_clock is None:
            self.draw_timeout_clock = Clock.schedule_once(self.on_draw_timeout, self.draw_timeout)

    def reset_canvas(self):
        self.canvas.clear()
        self.strokes.clear()
        self.stroke_times.clear()
        self.time_between_strokes.clear()
        self.start_time = None
        self.last_action = None
        self.gesture_completed = False
        if self.draw_timeout_clock is not None:
            self.draw_timeout_clock.cancel()
            self.draw_timeout_clock = None
    
    def on_draw_timeout(self, dt):
        self.canvas.clear()
        self.gesture_completed = True

    def on_use_random_color(self, instance, value):
        if not self.strokes:
            return

        for stroke in self.strokes:
            if value:
                Color(random(), random(), random())
                Line(points=stroke, width=2)
            else:
                Color(0, 0, 0)
                Line(points=stroke, width=2)

####################################################################################
# Screens #
####################################################################################
class LoginScreen(Screen):
    gesture_surface = ObjectProperty()

    password_db = None
    entered_password = {"gesture": None, "stroke_times": None, "time_between_strokes": None}

    def on_pre_enter(self):
        self.gesture_surface = self.ids.login_gesture_surface
        self.ids.username.text = ""
        self.reset()

    def create_account(self):
        screen_manager.transition = SlideTransition(direction='left')
        self.manager.current = 'CreateAccount'

    def gesture_completed(self):
        self.ids.login_button.disabled = False
        draw_checkmark(self.gesture_surface)

    def reset(self):
        self.gesture_surface.reset_canvas()
        self.ids.login_button.disabled = True

    def login(self):
        # get password from database using username
        client = MongoClient("mongodb://127.0.0.1:27017/mongosh?directConnection=true&serverSelectionTimeoutMS=2000")
        db = client.userDB
        user = db.user
        self.password_db = [p for p in user.find({"user_id": self.ids.username.text})]
        client.close()
        
        # if the username is not in database, len(password_db) will be 0, otherwise, len(password_db) will be 1
        if len(self.password_db) == 0:
            UserDoesNotExistPopup().open()
        else: 
            curr_time = time.time() - self.password_db[0]['last_login_attempt']
            if self.password_db[0]['login_attempts'] >= MAX_LOGIN_ATTEMPTS and curr_time < RATE_LIMIT_WINDOW:
                remaining_time = int((RATE_LIMIT_WINDOW - curr_time) // 60)
                popup = RateLimitPopup()
                popup.update_text(remaining_time)
                popup.open()
            else:
                recognizer.add_gesture("Password", self.password_db[0]['password']['gesture'])
                if self.gesture_surface.strokes:
                    self.entered_password["gesture"] = list(get_vectors(self.gesture_surface.strokes))
                    self.entered_password["stroke_times"] = list(self.gesture_surface.stroke_times)
                    self.entered_password["time_between_strokes"] = list(self.gesture_surface.time_between_strokes)
                    result = recognizer.recognize(self.entered_password["gesture"])
                    result.bind(on_complete=self.handle_recognize_complete)
            # else No Password Entered Popup

    def handle_recognize_complete(self, result, *l):
        client = MongoClient("mongodb://127.0.0.1:27017/mongosh?directConnection=true&serverSelectionTimeoutMS=2000")
        db = client.userDB
        user = db.user
        
        best = result.best
        if best['score'] >= SIMILARITY_THRESHOLD and compare_gesture_timing(self.password_db[0]['password']["stroke_times"], self.entered_password["stroke_times"]) and compare_gesture_timing(self.password_db[0]['password']["time_between_strokes"], self.entered_password["time_between_strokes"]):
            user.update_one({'user_is': self.ids.username.text}, {"$set": {"login_attempts": 0, 'last_login_attempt': time.time()}})
            client.close()
            self.logInSuccess()
        else:
            user.update_one({'user_id': self.ids.username.text}, {"$set": {"login_attempts": self.password_db[0]["login_attempts"] + 1, 'last_login_attempt': time.time()}})
            PasswordWrongPopup().open()
        client.close()

    def logInSuccess(self):
        self.reset()
        screen_manager.transition = SlideTransition(direction='left')
        self.manager.current = 'LoginSuccessful'

class CreateAccountScreen(Screen):
    gesture_surface = ObjectProperty()
    successful_repetitions = NumericProperty(0)

    create_recognizer = Recognizer()

    initial_gesture = {"gesture": None, "stroke_times": None, "time_between_strokes": None}
    inputted_gesture = {"gesture": None, "stroke_times": None, "time_between_strokes": None}
    
    def on_pre_enter(self):
        self.ids.username.text = ""
        self.successful_repetitions = 0
        self.gesture_surface = self.ids.create_account_gesture_surface
        self.reset_password()

    def on_initial_gesture_completed(self):
        if not check_complexity(get_points(self.gesture_surface.strokes)):
            self.gesture_surface.reset_canvas()
            SimplePasswordPopup().open()
        else: 
            self.initial_gesture["gesture"] = list(get_vectors(self.gesture_surface.strokes))
            self.initial_gesture["stroke_times"] = list(self.gesture_surface.stroke_times)
            self.initial_gesture["time_between_strokes"] = list(self.gesture_surface.time_between_strokes)
            self.create_recognizer.add_gesture('Password Being Created', self.initial_gesture["gesture"])
            self.gesture_surface.reset_canvas()
            PasswordInstructionPopup().open()

    def gesture_completed(self):
        if self.initial_gesture["gesture"] is None:
            self.on_initial_gesture_completed()
        else:
            self.inputted_gesture["gesture"] = list(get_vectors(self.gesture_surface.strokes))
            self.inputted_gesture["stroke_times"] = list(self.gesture_surface.stroke_times)
            self.inputted_gesture["time_between_strokes"] = list(self.gesture_surface.time_between_strokes)
            result = self.create_recognizer.recognize(self.inputted_gesture["gesture"])
            result.bind(on_complete=self.handle_recognize_complete)
            
    def handle_recognize_complete(self, result, *l):
        client = MongoClient("mongodb://127.0.0.1:27017/mongosh?directConnection=true&serverSelectionTimeoutMS=2000")
        db = client.userDB
        user = db.user
        best = result.best
        if best['score'] >= SIMILARITY_THRESHOLD and compare_gesture_timing(self.initial_gesture["stroke_times"], self.inputted_gesture["stroke_times"]) and compare_gesture_timing(self.initial_gesture["time_between_strokes"], self.inputted_gesture["time_between_strokes"]):
            draw_checkmark(self.gesture_surface)
            self.successful_repetitions += 1
            if self.successful_repetitions == 3:
                # serialized_vectors = [[list(vector) for vector in sublist] for sublist in password]
                # json_string = json.dumps(serialized_vectors)
                AccountCreationPopup().open()
                user.insert_one({'user_id': self.ids.username.text, 'password': self.initial_gesture, 'login_attempts': 0, 'last_login_attempt': time.time()})
                client.close()
        else:
            draw_x(self.gesture_surface)
            self.successful_repetitions = 0
        Clock.schedule_once(lambda dt: self.gesture_surface.reset_canvas(), 1)

    def reset_password(self):
        self.successful_repetitions = 0
        self.create_recognizer = Recognizer()
        self.initial_gesture = {"gesture": None, "stroke_times": None, "time_between_strokes": None}
        self.inputted_gesture = {"gesture": None, "stroke_times": None, "time_between_strokes": None}
        self.gesture_surface.reset_canvas()
        self.show_password_info_popup()

    def show_password_info_popup(self):
        PasswordInfoPopup().open()

    def has_account(self):
        screen_manager.transition = SlideTransition(direction='right')
        self.manager.current = 'Login'

class LoginSuccessfulScreen(Screen):
    def log_out(self):
        screen_manager.transition = SlideTransition(direction='right')
        self.manager.current = 'Login'

    

    def update_password(self):
        screen_manager.transition = SlideTransition(direction='left')
        self.manager.current = 'ChangePassword'

class ChangePasswordScreen(Screen):
    gesture_surface = ObjectProperty()
    successful_repetitions = NumericProperty(0)

    create_recognizer = Recognizer()

    initial_gesture = {"gesture": None, "stroke_times": None, "time_between_strokes": None}
    inputted_gesture = {"gesture": None, "stroke_times": None, "time_between_strokes": None}

    def on_pre_enter(self):
        self.ids.username.text = ""
        self.successful_repetitions = 0
        self.gesture_surface = self.ids.create_account_gesture_surface
        self.reset_password()
    
    def on_initial_gesture_completed(self):
        if not check_complexity(get_points(self.gesture_surface.strokes)):
            self.gesture_surface.reset_canvas()
            SimplePasswordPopup().open()
        else: 
            self.initial_gesture["gesture"] = list(get_vectors(self.gesture_surface.strokes))
            self.initial_gesture["stroke_times"] = list(self.gesture_surface.stroke_times)
            self.initial_gesture["time_between_strokes"] = list(self.gesture_surface.time_between_strokes)
            self.create_recognizer.add_gesture('Password Being Created', self.initial_gesture["gesture"])
            self.gesture_surface.reset_canvas()
            PasswordInstructionPopup().open()

    def gesture_completed(self):
        if self.initial_gesture["gesture"] is None:
            self.on_initial_gesture_completed()
        else:
            self.inputted_gesture["gesture"] = list(get_vectors(self.gesture_surface.strokes))
            self.inputted_gesture["stroke_times"] = list(self.gesture_surface.stroke_times)
            self.inputted_gesture["time_between_strokes"] = list(self.gesture_surface.time_between_strokes)
            result = self.create_recognizer.recognize(self.inputted_gesture["gesture"])
            result.bind(on_complete=self.handle_recognize_complete)
            
    def handle_recognize_complete(self, result, *l):
        client = MongoClient("mongodb://127.0.0.1:27017/mongosh?directConnection=true&serverSelectionTimeoutMS=2000")
        db = client.userDB
        user = db.user
        best = result.best
        if best['score'] >= SIMILARITY_THRESHOLD and compare_gesture_timing(self.initial_gesture["stroke_times"], self.inputted_gesture["stroke_times"]) and compare_gesture_timing(self.initial_gesture["time_between_strokes"], self.inputted_gesture["time_between_strokes"]):
            draw_checkmark(self.gesture_surface)
            self.successful_repetitions += 1
            if self.successful_repetitions == 3:
                # serialized_vectors = [[list(vector) for vector in sublist] for sublist in password]
                # json_string = json.dumps(serialized_vectors)
                PasswordUpdatedPopup().open()
                myQuery ={'user_id':self.ids.username.text}
                user.delete_one(myQuery)
                user.insert_one({'user_id': self.ids.username.text, 'password': self.initial_gesture, 'login_attempts': 0, 'last_login_attempt': time.time()})
                
                # client.close()
        else:
            draw_x(self.gesture_surface)
            self.successful_repetitions = 0
        Clock.schedule_once(lambda dt: self.gesture_surface.reset_canvas(), 1)

    def reset_password(self):
        self.successful_repetitions = 0
        self.create_recognizer = Recognizer()
        self.initial_gesture = {"gesture": None, "stroke_times": None, "time_between_strokes": None}
        self.inputted_gesture = {"gesture": None, "stroke_times": None, "time_between_strokes": None}
        self.gesture_surface.reset_canvas()
        self.show_password_info_popup()

    def show_password_info_popup(self):
        PasswordInfoPopup().open()

    def has_account(self):
        screen_manager.transition = SlideTransition(direction='right')
        self.manager.current = 'Login'

####################################################################################
# Main #
####################################################################################
class GestureLock(App):
    win_size = scr_w, scr_h

    def build(self):
        screen_manager.add_widget(LoginScreen(name='Login'))
        screen_manager.add_widget(CreateAccountScreen(name='CreateAccount'))
        screen_manager.add_widget(LoginSuccessfulScreen(name='LoginSuccessful'))
        screen_manager.add_widget(ChangePasswordScreen(name='ChangePassword'))
        screen_manager.current = 'Login'
        return screen_manager


if __name__ == '__main__':
    GestureLock().run()